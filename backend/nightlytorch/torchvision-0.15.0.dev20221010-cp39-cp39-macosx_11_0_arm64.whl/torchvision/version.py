__version__ = '0.15.0.dev20221010'
git_version = '4b5704577b0b64fbda9fcfa0e110ec9eab1ed9d4'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
