__version__ = '0.15.0.dev20221007'
git_version = '89905899bda9fb094afbf0355e525385d7bcdb03'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
